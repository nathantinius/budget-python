from django.apps import AppConfig


class BudgetapiConfig(AppConfig):
    name = 'budgetapi'
